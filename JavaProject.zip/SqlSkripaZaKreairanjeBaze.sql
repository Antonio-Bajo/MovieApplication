--------- #DATABASE FOR UNI PROJECT# ------------------
CREATE DATABASE Java1Project
GO
USE Java1Project
GO

-------------------------------------
-------------TABLE INIT--------------
CREATE TABLE AppUser
(
	IDAppUser INT PRIMARY KEY IDENTITY,
	UserName NVARCHAR(50) NOT NULL,
	UserPassword NVARCHAR(50) NOT NULL,
	AdminRights bit NOT NULL
)
GO
INSERT into AppUser (UserName,UserPassword,AdminRights) VALUES  ('admin','admin',1) -- Administrator
GO

CREATE TABLE Person
(
	IDPerson INT PRIMARY KEY IDENTITY,
	FirstName NVARCHAR(30) NOT NULL,
	LastName NVARCHAR(30) NOT NULL,
)
GO
CREATE TABLE Genre
(
	IDGenre INT PRIMARY KEY IDENTITY,
	Genre NVARCHAR(20) NOT NULL,
)
GO
CREATE TABLE Movie
(
	IDMovie INT PRIMARY KEY IDENTITY,
	Title NVARCHAR(50) NOT NULL,
	OriginalName NVARCHAR(50) NOT NULL,
	PublishedDate NVARCHAR(90) NOT NULL,
	Descriptionn NVARCHAR(max) NOT NULL,
	RedateljID int foreign key references Person(IDPerson) not null,
	ImagePath NVARCHAR(max) NOT NULL,
	Link NVARCHAR(max) NOT NULL,
	ReleaseDate NVARCHAR(90) NOT NULL,
	Lengthh int NOT NULL,
)
GO
CREATE TABLE MovieGenre
(
	IDMovieGenre INT PRIMARY KEY IDENTITY,
	MovieID int foreign key references Movie(IDMovie) not null,
	GenreID int foreign key references Genre(IDGenre) not null,
)
GO

CREATE TABLE MovieActor
(
	IDMovieActor INT PRIMARY KEY IDENTITY,
	MovieID int foreign key references Movie(IDMovie) not null,
	PersonID int foreign key references Person(IDPerson) not null,
)
GO



---------PROCEDURE INIT--------------
-------------------------------------

--CRUD Person
CREATE PROCEDURE createPerson
	@FirstName NVARCHAR(20),
	@LastName NVARCHAR(20),
	@Id INT OUTPUT
AS 
BEGIN 
	INSERT INTO Person (FirstName,LastName) VALUES(@FirstName,@LastName)
	SET @Id = SCOPE_IDENTITY()
END
GO

CREATE PROCEDURE selectPerson
	@IdPerson INT
AS 
BEGIN 
	select * from Person where IDPerson = @IdPerson
END
GO


CREATE PROCEDURE selectPersons
AS 
BEGIN 
	select * from Person
END
GO

CREATE PROCEDURE updatePerson
	@FirstName NVARCHAR(20),
	@LastName NVARCHAR(20),
	@IdPerson INT
	 
AS 
BEGIN 
	UPDATE Person SET 
		FirstName = @FirstName, 
		LastName = @LastName
	WHERE 
		IDPerson = @IdPerson
END
GO


CREATE PROCEDURE deletePerson
	@IdPerson INT	 
AS 
BEGIN 
	DELETE from Person WHERE IDPerson=@IdPerson
END
GO

CREATE PROCEDURE deletePersons 
AS 
BEGIN 
	DELETE from Person 
END
GO

CREATE PROCEDURE createOrGetPerson
	@FirstName NVARCHAR(20),
	@LastName NVARCHAR(20),
	@Id INT OUTPUT
AS 
BEGIN 
	IF exists(select * from Person as p where p.Firstname=@FirstName and p.Lastname=@Lastname)
		BEGIN
		 select @Id= p.IDPerson from Person as p where p.Firstname=@FirstName and p.Lastname=@Lastname
		END
	ELSE
		BEGIN
			INSERT INTO Person(FirstName,LastName) VALUES(@FirstName, @LastName)
			SET @Id = SCOPE_IDENTITY()
		END
END
GO



--CRUD Movies
CREATE PROCEDURE createMovie
	@Title NVARCHAR(50),
	@OriginalName NVARCHAR(50),
	@PublishedDate NVARCHAR(90),
	@Descriptionn NVARCHAR(max),
	@RedateljID int,
	@ImagePath NVARCHAR(max),
	@Link NVARCHAR(max),
	@ReleaseDate NVARCHAR(90) ,
	@Length int,
	@Id INT OUTPUT
AS 
BEGIN 
	INSERT INTO Movie(Title,OriginalName,PublishedDate,Descriptionn,RedateljID,ImagePath,Link,ReleaseDate,Lengthh)
	VALUES(@Title,@OriginalName,@PublishedDate,@Descriptionn,@RedateljID,@ImagePath,@Link,@ReleaseDate,@Length)

	SET @Id = SCOPE_IDENTITY()
END
GO

CREATE PROCEDURE updateMovie
	@Title NVARCHAR(50),
	@OriginalName NVARCHAR(50),
	@PublishedDate NVARCHAR(90),
	@Descriptionn NVARCHAR(max),
	@RedateljID int,
	@ImagePath NVARCHAR(max),
	@Link NVARCHAR(max),
	@ReleaseDate NVARCHAR(90),
	@Length int,
	@IdMovie INT
AS 
BEGIN 
	UPDATE Movie SET 
		Title = @Title,
		OriginalName = @OriginalName,
		PublishedDate = @PublishedDate,
		Descriptionn = @Descriptionn,
		RedateljID = @RedateljID,
		ImagePath = @ImagePath,
		Link = @Link,
		ReleaseDate = @ReleaseDate,
		Lengthh = @Length
	WHERE 
		IDMovie = @IdMovie
END
GO

CREATE PROCEDURE deleteMovie
	@IdMovie INT	 
AS 
BEGIN 
	DELETE from MovieGenre WHERE MovieID = @IdMovie
	DELETE from MovieActor WHERE MovieID = @IdMovie
	DELETE from Movie WHERE IDMovie = @IdMovie
END
GO

CREATE PROCEDURE deleteMovies 
AS 
BEGIN 
	DELETE from MovieGenre 
	DELETE from MovieActor
	DELETE from Movie 
END
GO


create PROCEDURE selectMovie
	@IdMovie INT
AS 
BEGIN 
select IDMovie,Title,OriginalName,PublishedDate,Descriptionn,RedateljID,ImagePath,Link,Lengthh,ReleaseDate,
(select CAST(RedateljID as NVARCHAR(10)) + ' ' +FirstName + ' ' + LastName from Person where RedateljID = IDPerson) as Redatelj,
STRING_AGG(CAST(IDGenre as NVARCHAR(10))+' ' +  genre,',') within group(order by genre) as Genres,
STRING_AGG(CAST(MovieActor.PersonID as NVARCHAR(10)) + ' '+FirstName + ' ' + LastName,',') within group(order by genre) as Actors
	from Movie
	left join MovieActor on Movie.IDMovie = MovieActor.MovieID
	left join Person on IDPerson=PersonID
	left join MovieGenre on Movie.IDMovie = MovieGenre.MovieID
	left join Genre on MovieGenre.GenreID = Genre.IDGenre
	group by IDMovie,Title,OriginalName,PublishedDate,Descriptionn,RedateljID,ImagePath,Link,Lengthh,ReleaseDate
	having  Movie.IDMovie = @IdMovie
END
GO

CREATE PROCEDURE selectMovies
AS 
BEGIN 
select IDMovie,Title,OriginalName,PublishedDate,Descriptionn,RedateljID,ImagePath,Link,Lengthh,ReleaseDate,
(select CAST(RedateljID as NVARCHAR(10)) + ' ' +FirstName + ' ' + LastName from Person where RedateljID = IDPerson) as Redatelj,
STRING_AGG(CAST(IDGenre as NVARCHAR(10))+' ' +  genre,',') within group(order by genre) as Genres,
STRING_AGG(CAST(MovieActor.PersonID as NVARCHAR(10)) + ' '+FirstName + ' ' + LastName,',') within group(order by genre) as Actors
	from Movie
	left join MovieActor on Movie.IDMovie = MovieActor.MovieID
	left join Person on IDPerson=PersonID
	left join MovieGenre on Movie.IDMovie = MovieGenre.MovieID
	left join Genre on MovieGenre.GenreID = Genre.IDGenre
	group by IDMovie,Title,OriginalName,PublishedDate,Descriptionn,RedateljID,ImagePath,Link,Lengthh,ReleaseDate
END
GO


--CRUD Genre
CREATE PROCEDURE createGenre
	@Genre NVARCHAR(20),
	@Id INT OUTPUT
AS 
BEGIN 
	INSERT INTO Genre (Genre) VALUES(@Genre)
	SET @Id = SCOPE_IDENTITY()
END
GO

CREATE PROCEDURE selectGenre
	@IdGenre INT
AS 
BEGIN 
	select * from Genre where IDGenre=@IdGenre
END
GO


CREATE PROCEDURE selectGenres
AS 
BEGIN 
	select * from Genre
END
GO

CREATE PROCEDURE updateGenre
	@Genre NVARCHAR(20),
	@IdGenre INT
	 
AS 
BEGIN 
	UPDATE Genre SET 
		Genre = @Genre
	WHERE 
		IDGenre = @IdGenre
END
GO


CREATE PROCEDURE deleteGenre
	@IdGenre INT	 
AS 
BEGIN 

	DELETE from Genre WHERE IDGenre=@IdGenre
END
GO

CREATE PROCEDURE deleteGenres 
AS 
BEGIN 
	DELETE from Genre
END
GO

CREATE PROCEDURE createOrGetGenre
	@Genre NVARCHAR(20),
	@Id INT OUTPUT
AS 
BEGIN 
	IF exists(select * from Genre as G where G.Genre=@Genre)
		BEGIN
		 select @Id = G.IDGenre from Genre as G where G.Genre=@Genre
		END
	ELSE
		BEGIN
			INSERT INTO Genre VALUES(@Genre)
			SET @Id = SCOPE_IDENTITY()
		END
END
GO


--MoviePerson
CREATE PROCEDURE createMovieActor
	@MovieId INT,
	@PersonId INT,
	@Id INT OUTPUT
AS
BEGIN
	insert into MovieActor(MovieID,PersonID) VALUES (@MovieId,@PersonId)
	SET @Id = SCOPE_IDENTITY()
END
GO

CREATE PROCEDURE deleteMovieActors
	@MovieId INT
AS 
BEGIN 
	DELETE from MovieActor WHERE MovieID=@MovieId
END
GO



--MovieGenre
CREATE PROCEDURE createMovieGenre
	@MovieId INT,
	@GenreId INT,
	@Id INT OUTPUT
AS
BEGIN
	insert into MovieGenre(MovieID,GenreID) VALUES (@MovieId,@GenreId)
	SET @Id = SCOPE_IDENTITY()
END
GO

CREATE PROCEDURE deleteMovieGenres 
	@MovieId INT
AS 
BEGIN 
	DELETE from MovieGenre WHERE MovieID=@MovieId
END
GO



--AppUser
CREATE PROCEDURE createAppUser
	@UserName NVARCHAR(50),
	@UserPassword NVARCHAR(50),
	@AdminRights bit,
	@Id INT OUTPUT
AS 
BEGIN
	INSERT INTO AppUser (UserName,UserPassword,AdminRights)VALUES(@UserName,@UserPassword,@AdminRights)
	SET @Id = SCOPE_IDENTITY()
END
GO

CREATE PROCEDURE selectAppUserByCredentials
	@UserName NVARCHAR(50),
	@UserPassword NVARCHAR(50)
AS
BEGIN
	SELECT * from AppUser WHERE UserName = @UserName AND UserPassword = @UserPassword
END
GO

CREATE PROCEDURE selectAppUserByUserName
	@UserName NVARCHAR(50)
AS
BEGIN
	SELECT * from AppUser WHERE UserName = @UserName
END

