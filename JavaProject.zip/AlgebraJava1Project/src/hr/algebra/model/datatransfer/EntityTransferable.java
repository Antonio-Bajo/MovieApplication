/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.datatransfer;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.Objects;

/**
 *
 * @author Antonio
 * @param <T>
 */
//with using generics and entity passed with constructor this class can work with any Object(entity)!
public class EntityTransferable<T> implements Transferable {

    private final DataFlavor entitiyFlavor;
    private final DataFlavor[] supportedFlavors;

    private final T entity;

    public EntityTransferable(T entity) { // parameterized constructor
        this.entity = Objects.requireNonNull(entity);
        entitiyFlavor = new DataFlavor(entity.getClass(), entity.getClass().getName());
        supportedFlavors = new DataFlavor[]{entitiyFlavor};
    }

    @Override
    public DataFlavor[] getTransferDataFlavors() {
        return supportedFlavors;
    }

    @Override
    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return flavor.equals(entitiyFlavor);
    }

    @Override
    public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
        //is flavor is supported then return entity
        if (isDataFlavorSupported(flavor)) {
            return entity;
        }
        throw new UnsupportedFlavorException(flavor);
    }
}
