/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.datatransfer;

import java.awt.datatransfer.Transferable;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.TransferHandler;

/**
 *
 * @author Antonio
 * @param <T>
 */
//with using generics and params passed with constructor this class can work with any JList, also becuase of that this method can be in its own package! (we dont need tight reletionship anymore)
public class ExportHandler<T> extends TransferHandler {

    private final JList<T> list;
    private final int actionIcon;

    public ExportHandler(JList<T> list) {
        this.actionIcon = TransferHandler.COPY; //default value
        this.list = list;
    }

    public ExportHandler(JList<T> list, TransferAction actionIcon) {
        this.list = list;
        this.actionIcon = actionIcon.getValue(); //we use enum to restrict only valid int's
    }

    @Override
    public int getSourceActions(JComponent c) {
        //visual aspect
        return actionIcon;
    }

    @Override
    protected Transferable createTransferable(JComponent c) {
        return new EntityTransferable<>(list.getSelectedValue());
    }

    public static enum TransferAction {
        NONE(ExportHandler.NONE),
        COPY(ExportHandler.COPY),
        MOVE(ExportHandler.MOVE),
        COPY_OR_MOVE(ExportHandler.COPY_OR_MOVE),
        LINK(ExportHandler.LINK);

        private final int actionIcon;

        private TransferAction(int actionIcon) {
            this.actionIcon = actionIcon;
        }

        public int getValue() {
            return actionIcon;
        }

    }

}
