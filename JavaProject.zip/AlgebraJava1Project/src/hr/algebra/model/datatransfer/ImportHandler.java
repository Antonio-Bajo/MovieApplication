/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.datatransfer;

import hr.algebra.MoviePanel;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.TransferHandler;

/**
 *
 * @author Antonio
 * @param <T>
 */
//with using generics and params passed with constructor this class works with any object,also this class dosent need tight reletionship anymore.
//if DataFlavor(1.param) is supported then call Consumer(2. param)(callback function)
public class ImportHandler<T> extends TransferHandler {

    private final DataFlavor dataFlavor;
    private final Consumer<T> consumer;

    public ImportHandler(DataFlavor dataFlavor, Consumer<T> consumer) {
        this.dataFlavor = Objects.requireNonNull(dataFlavor);
        this.consumer = consumer;
    }

    @Override
    public boolean canImport(TransferHandler.TransferSupport support) {
        return support.isDataFlavorSupported(dataFlavor);
    }

    //imports data from support and calls consumer. All types are parameterized.
    @Override
    public boolean importData(TransferHandler.TransferSupport support) {
        try {
            T data = (T) support.getTransferable().getTransferData(dataFlavor);

            consumer.accept(data);

        } catch (UnsupportedFlavorException | IOException ex) {
            Logger.getLogger(MoviePanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
