/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.datatransfer;

import hr.algebra.model.Genre;
import hr.algebra.model.Person;
import java.awt.datatransfer.DataFlavor;

/**
 *
 * @author Antonio
 */
public enum MyDataFlavors {
    PersonFlavor(new DataFlavor(Person.class, "Person")),
    GenreFlavor(new DataFlavor(Genre.class, "Genre"));

    private final DataFlavor dataFlavor;

    private MyDataFlavors(DataFlavor dataFlavor) {
        this.dataFlavor = dataFlavor;
    }

    public DataFlavor getDataFlavor() {
        return dataFlavor;
    }
}
