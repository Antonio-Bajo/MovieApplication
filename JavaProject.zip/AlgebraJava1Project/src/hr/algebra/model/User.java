/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

/**
 *
 * @author Antonio
 */
public class User {

    private int id;
    private final String userName;
    private final String userPassword;
    private final UserRole role;

    public int getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public UserRole getRole() {
        return role;
    }

    public User(int id, String userName, String userPassword, UserRole role) {
        this.id = id;
        this.userName = userName;
        this.userPassword = userPassword;
        this.role = role;
    }

    public User(String userName, String userPassword, UserRole role) {
        this.userName = userName;
        this.userPassword = userPassword;
        this.role = role;
    }

}
