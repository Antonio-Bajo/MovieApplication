/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

/**
 *
 * @author Antonio
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class Genre implements Comparable<Genre> {

    @XmlAttribute
    private int id;
    @XmlElement(name = "genre")
    private String genre;

    public Genre() {
    }

    public static Genre newInstance(Genre genre) { //Copy factory
        return new Genre(genre.getId(), genre.getGenre());
    }

    public Genre(String genre) {
        this.genre = genre;
    }

    public Genre(int id, String genre) {
        this.id = id;
        this.genre = genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getId() {
        return id;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return genre;
    }

    @Override
    public int compareTo(Genre o) {
        return genre.compareToIgnoreCase(o.getGenre());
    }

}
