/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.swing;

import hr.algebra.model.Person;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Antonio
 */
public class PersonTableModel extends AbstractTableModel {

    private static final String[] COLUMNS = {"Id", "First name", "Last name"};
    private List<Person> persons;

    public PersonTableModel() {
        persons = new ArrayList<>();
    }

    
    public PersonTableModel(List<Person> persons) {
        this.persons = persons;
    }

    public void setPersons(List<Person> persons) {
        this.persons = persons;
        //refresh
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return persons.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length ;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return persons.get(rowIndex).getId();
            case 1:
                return persons.get(rowIndex).getFirstName();
            case 2:
                return persons.get(rowIndex).getLastName();
        }

        throw new IllegalArgumentException("No such colum");
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return Integer.class;
        }

        return super.getColumnClass(columnIndex); //To change body of generated methods, choose Tools | Templates.
    }
}
