/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.swing;

import hr.algebra.model.Genre;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Antonio
 */
public class GenreTableModel extends AbstractTableModel{
     private static final String[] COLUMNS = {"Id", "Genre"};
    private List<Genre> genres;

     public GenreTableModel() {
        genres = new ArrayList<>();
    }
     
    public GenreTableModel(List<Genre> genres) {
        this.genres = genres;
    }

    public void setGenres(List<Genre> genres) {
        this.genres = genres;
        //refresh
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return genres.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length ;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return genres.get(rowIndex).getId();
            case 1:
                return genres.get(rowIndex).getGenre();
        }

        throw new IllegalArgumentException("No such colum");
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return Integer.class;
        }

        return super.getColumnClass(columnIndex); //To change body of generated methods, choose Tools | Templates.
    }
}
