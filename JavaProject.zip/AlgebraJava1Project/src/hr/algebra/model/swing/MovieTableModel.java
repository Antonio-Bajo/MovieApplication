/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model.swing;

import hr.algebra.model.Movie;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Antonio
 */
public class MovieTableModel extends AbstractTableModel {

    private static final String[] COLUMNS = {"Id", "Title", "Genres", "Director", "Release date",};
    private List<Movie> movies;

    public MovieTableModel() { //in case we need default constructor, we make sure movies are initialized. (helpfull in moviePanel at inicializing panel.)
        movies = new ArrayList<>();
    } 

    public MovieTableModel(List<Movie> movies) {
        this.movies = movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
        //refresh
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return movies.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length ;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return movies.get(rowIndex).getId();
            case 1:
                return movies.get(rowIndex).getTitle();
            case 2:
                return movies.get(rowIndex).getGenres();
            case 3:
                return movies.get(rowIndex).getDirector();
            case 4:
                return movies.get(rowIndex).getReleaseDate();

        }

        throw new IllegalArgumentException("No such colum");
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return Integer.class;
        }

        return super.getColumnClass(columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

}
