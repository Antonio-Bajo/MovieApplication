/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

import java.util.Comparator;
import java.util.Objects;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

/**
 *
 * @author Antonio
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class Person implements Comparable<Person> {

    @XmlAttribute
    private int id;
    @XmlElement(name = "firstname")
    private String firstName;
    @XmlElement(name = "lastname")
    private String lastName;

    //Default constuctor for JAXB api
    public Person() {
    }

    public static Person newInstance(Person person) { //copy factory 
        return new Person(person.getId(), person.getFirstName(), person.getLastName());
    }

    //za kreairanje persona u jForm
    public Person(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getId() {
        return id;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }

    @Override
    public int compareTo(Person o) { //compares person via username and lastname (ignores case)
        return Comparator.comparing((Person p) -> p.getFirstName().toLowerCase()).thenComparing((Person p) -> p.getLastName().toLowerCase()).compare(this, o);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Person) {
            return id == ((Person) obj).id;
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + this.id;
        return hash;
    }

    //2 David Jude Law
    public static Person parseFromString(String string) {
        if (Objects.requireNonNull(string).contains(",")) {
            throw new IllegalArgumentException("Passed parametar contains illegal character");
        }
        String[] data = string.split(" ");
        if (data.length < 3) {
            throw new IllegalArgumentException("Passed parametar is missing data");
        }
        String id = data[0].trim(); //2 
        String firstName = data[1].trim(); //David
        String lastName = string.substring(firstName.length() + id.length()).trim(); //Jude Law

        return new Person(Integer.parseInt(id), firstName, lastName);
    }

}
