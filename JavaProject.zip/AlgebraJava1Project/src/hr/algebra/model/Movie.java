/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

import hr.algebra.annotation.adapters.ReleaseDateAdapter;
import hr.algebra.annotation.adapters.PublishedDateAdapter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 *
 * @author Antonio
 */
//This class only provides defensive copies on getters of actors and genres. No other defensive copies are needed for this project.
@XmlAccessorType(XmlAccessType.FIELD)
public class Movie {

    public static final DateTimeFormatter PUB_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    public static final DateTimeFormatter RELEASE_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;

    @XmlAttribute
    private int id;
    private String title;
    private String OriginalName;
    @XmlJavaTypeAdapter(PublishedDateAdapter.class)
    @XmlElement(name = "publishdate")
    private LocalDateTime publishedDate;
    private int length;
    private String description;
    @XmlElementWrapper
    @XmlElement(name = "genre")
    private Set<Genre> genres;
    private Person director;
    @XmlElementWrapper
    @XmlElement(name = "actor")
    private Set<Person> actors;
    private String ImagePath;
    private String link;
    @XmlJavaTypeAdapter(ReleaseDateAdapter.class)
    @XmlElement(name = "releasedate")
    private LocalDate releaseDate;

    //needs default constructor for JAXB
    public Movie() { //if we use this constructor, we must inicialize our Set's incase of using add methods on Genre and actors.
        genres = new TreeSet<>();
        actors = new TreeSet<>();
    }

    public Movie(String title, String OriginalName, LocalDateTime publishedDate, int length, String description, Set<Genre> genre, Person redatelj, Set<Person> actors, String ImagePath, String link, LocalDate releaseDate) {
        this.title = title;
        this.OriginalName = OriginalName;
        this.publishedDate = publishedDate;
        this.length = length;
        this.description = description;
        this.genres = genre;
        this.director = redatelj;
        this.actors = actors;
        this.ImagePath = ImagePath;
        this.link = link;
        this.releaseDate = releaseDate;
    }

    public Movie(int id, String title, String OriginalName, LocalDateTime publishedDate, int length, String description, Set<Genre> genres, Person director, Set<Person> actors, String ImagePath, String link, LocalDate releaseDate) {
        this.id = id;
        this.title = title;
        this.OriginalName = OriginalName;
        this.publishedDate = publishedDate;
        this.length = length;
        this.description = description;
        this.genres = genres;
        this.director = director;
        this.actors = actors;
        this.ImagePath = ImagePath;
        this.link = link;
        this.releaseDate = releaseDate;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOriginalName() {
        return OriginalName;
    }

    public void setOriginalName(String OriginalName) {
        this.OriginalName = OriginalName;
    }

    public LocalDateTime getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(LocalDateTime publishedDate) {
        this.publishedDate = Objects.requireNonNull(publishedDate);
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Genre> getGenres() {
        return genres.stream().map(Genre::newInstance).collect(Collectors.toCollection(TreeSet::new)); // Genre is mutable so we return deep copy of Set.
    }

    public void setGenres(Set<Genre> genres) {
        this.genres = genres;
    }

    public Person getDirector() {
        return director;
    }

    public void setDirector(Person director) {
        this.director = Objects.requireNonNull(director);
    }

    public Set<Person> getActors() {
        return actors.stream().map(Person::newInstance).collect(Collectors.toCollection(TreeSet::new)); // Person is mutable so we return deep copy of Set.
    }

    public void setActors(Set<Person> actors) {
        this.actors = actors;
    }

    public String getImagePath() {
        return ImagePath;
    }

    public void setImagePath(String ImagePath) {
        this.ImagePath = ImagePath;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = Objects.requireNonNull(releaseDate);
    }

    @Override
    public String toString() {
        return title + " : " + OriginalName;
    }

    public void addGenre(Genre genre) {
        this.genres.add(Objects.requireNonNull(genre));
    }

    public void addActor(Person actor) {
        this.actors.add(Objects.requireNonNull(actor));
    }

}
