/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Antonio
 * @param <T>
 */
public interface Repository<T> {

    int createEntity(T entity) throws Exception;

    void createEntities(List<T> entities) throws Exception;

    void updateEntity(int id, T data) throws Exception;

    void deleteEntity(int id) throws Exception;

    void deleteEntities() throws Exception;

    Optional<T> selectEntity(int id) throws Exception;

    List<T> selectEntities() throws Exception;

    //skeletal implementation via default method.
    //implementators that supports createOrGetEntity() must override this method.
    default T createOrGetEntity(T entity) throws Exception {
        throw new UnsupportedOperationException("Not supported.");
    }
}
