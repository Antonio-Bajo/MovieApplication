/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal.sql;

import hr.algebra.model.Genre;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import hr.algebra.dal.Repository;

/**
 *
 * @author Antonio
 */
public class GenreRepository implements Repository<Genre> {

    private static final String ID_GENRE = "IDGenre";
    private static final String GENRE = "Genre";

    private static final String CREATE_GENRE = "{ CALL createGenre (?,?) }";
    private static final String UPDATE_GENRE = "{ CALL updateGenre (?,?) }";
    private static final String DELETE_GENRE = "{ CALL deleteGenre (?) }";
    private static final String DELETE_GENRES = "{ CALL deleteGenres }";
    private static final String SELECT_GENRE = "{ CALL selectGenre (?) }";
    private static final String SELECT_GENRES = "{ CALL selectGenres }";
    private static final String CREATE_OR_GET_GENRE = "{ CALL createOrGetGenre (?,?) }";

    @Override
    public int createEntity(Genre genre) throws Exception  {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_GENRE)) {
            stmt.setString(1, genre.getGenre());

            stmt.registerOutParameter(2, Types.INTEGER);

            stmt.executeUpdate();

            return stmt.getInt(2);
        }
    }

    @Override
    public void createEntities(List<Genre> genres) throws Exception  {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_GENRE)) {
            for (Genre genre : genres) {

                stmt.setString(1, genre.getGenre());

                stmt.registerOutParameter(2, Types.INTEGER);

                stmt.executeUpdate();
            }

        }
    }

    @Override
    public void updateEntity(int id, Genre data) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(UPDATE_GENRE)) {
            stmt.setString(1, data.getGenre());

            stmt.setInt(2, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteEntity(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_GENRE)) {
            stmt.setInt(1, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteEntities() throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_GENRES)) {

            stmt.executeUpdate();
        }
    }

    @Override
    public Optional<Genre> selectEntity(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_GENRE)) {
            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Genre(rs.getInt(ID_GENRE), rs.getString(GENRE)));
                }
            }

        }
        return Optional.empty();
    }

    @Override
    public List<Genre> selectEntities() throws Exception {
        List<Genre> genres = new ArrayList<>();

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_GENRES)) {

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) { //dok god imas recorde (articles)
                    genres.add(new Genre(rs.getInt(ID_GENRE), rs.getString(GENRE)));

                }
            }

        }
        return genres;
    }

    @Override
    public Genre createOrGetEntity(Genre genre) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_OR_GET_GENRE)) {
            stmt.setString(1, genre.getGenre());

            stmt.registerOutParameter(2, Types.INTEGER);

            stmt.executeUpdate();

            //will always be present!
            return selectEntity(stmt.getInt(2)).get();
        }
    }

}
