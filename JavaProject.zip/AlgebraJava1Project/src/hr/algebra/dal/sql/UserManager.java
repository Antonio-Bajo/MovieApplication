/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal.sql;

import hr.algebra.model.User;
import hr.algebra.model.UserRole;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Optional;
import javax.sql.DataSource;
import hr.algebra.dal.Authenticatable;

/**
 *
 * @author Antonio
 */
public final class UserManager implements Authenticatable {

    private static final String ID_APPUSER = "IDAppUser";
    private static final String USER_NAME = "UserName";
    private static final String USER_PASSWORD = "UserPassword";
    private static final String ADMIN_RIGHTS = "AdminRights";

    private static final String CREATE_APPUSER = "{ CALL createAppUser (?,?,?,?) }";
    private static final String SELECT_USER_BY_CREDENTIALS = "{ CALL selectAppUserByCredentials (?,?) }";
    private static final String SELECT_USER_BY_USERNAME = "{ CALL selectAppUserByUserName (?) }";

    private static final UserManager USER_MANAGER = new UserManager();

    //immutable class with static factory - flexible and returns same instance when invoked.
    public static UserManager getInstance() {
        return USER_MANAGER;
    }

    private UserManager() {
    }

    //Creates and returns Optional.of(user). 
    //Returns Optional.empty() if an user with that username and password in database already exists.
    @Override
    public Optional<User> createUser(User user) throws Exception {
        if (userNameExists(user.getUserName())) {
            return Optional.empty();
        }

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_APPUSER)) {
            stmt.setString(1, user.getUserName());
            stmt.setString(2, user.getUserPassword());
            stmt.setBoolean(3, user.getRole().isAppAdmin());

            stmt.registerOutParameter(4, Types.INTEGER);

            stmt.executeUpdate();

            return Optional.of(new User(stmt.getInt(4), user.getUserName(), user.getUserPassword(), user.getRole()));
        }
    }

    //Checks in database if user exists and returns Optional based on it.
    @Override
    public Optional<User> loginUser(String userName, String userPassword) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_USER_BY_CREDENTIALS)) {
            stmt.setString(1, userName);
            stmt.setString(2, userPassword);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new User(
                            rs.getInt(ID_APPUSER),
                            rs.getString(USER_NAME),
                            rs.getString(USER_PASSWORD),
                            rs.getBoolean(ADMIN_RIGHTS) ? UserRole.ADMIN : UserRole.USER));
                }
            }

        }
        return Optional.empty();
    }

    private boolean userNameExists(String userName) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_USER_BY_USERNAME)) {
            stmt.setString(1, userName);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return true;
                }
            }

        }
        return false;
    }

}
