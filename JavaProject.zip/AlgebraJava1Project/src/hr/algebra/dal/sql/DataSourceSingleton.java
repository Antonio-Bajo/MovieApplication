/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal.sql;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import javax.sql.DataSource;

/**
 *
 * @author Antonio
 */
public class DataSourceSingleton {

    //Citaj iz file-a za configuraciju baze! 
    private static final String CONFIG = "config.txt";

    //conection properties
    private static String SERVER;
    private static String DB;
    private static String USER;
    private static String PWD;

    private DataSourceSingleton() {
    }

    private volatile static DataSource INSTANCE;

    /**
     *
     * @return same instance of DataSource with configuration from config file.
     *
     * @throws IOException if config file is missing or its content is not in
     * right format.
     *
     */
    public static DataSource getInstance() throws IOException {
        if (INSTANCE == null) {
            synchronized (DataSource.class) {
                if (INSTANCE == null) {
                    INSTANCE = createInstance();
                }
            }

        }
        return INSTANCE;
    }

    private static DataSource createInstance() throws IOException {
        initConnectionProperties();

        SQLServerDataSource dataSource = new SQLServerDataSource();
        dataSource.setServerName(SERVER);
        dataSource.setDatabaseName(DB);
        dataSource.setUser(USER);
        dataSource.setPassword(PWD);

        return dataSource;
    }

    private static void initConnectionProperties() throws IOException {

        List<String> lines = Files.readAllLines(Paths.get(CONFIG));

        List<String> configData = lines.stream()
                .filter(l -> !l.startsWith("//")) //skip "commented" lines //
                .map(l -> l.substring(l.indexOf(":") + 1))
                .collect(Collectors.toList());

        if (configData.size() != 4) {
            throw new IOException("sql config file content is not in right format.");
        }
        SERVER = configData.get(0);
        DB = configData.get(1);
        USER = configData.get(2);
        PWD = configData.get(3);

    }

}
