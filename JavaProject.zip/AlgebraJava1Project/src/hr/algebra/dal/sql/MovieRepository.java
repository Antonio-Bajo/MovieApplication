/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal.sql;

import hr.algebra.model.Genre;
import hr.algebra.model.Movie;
import hr.algebra.model.Person;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import hr.algebra.dal.Repository;

/**
 *
 * @author Antonio
 */
public class MovieRepository implements Repository<Movie> {

    //Movie table
    private static final String ID_MOVIE = "IDMovie";
    private static final String TITLE = "Title";
    private static final String ORIGINAL_NAME = "OriginalName";
    private static final String PUBLISHED_DATE = "PublishedDate";
    private static final String DESCRIPTION = "Descriptionn";
    private static final String IMAGE_PATH = "ImagePath";
    private static final String LINK = "Link";
    private static final String LENGTH = "Lengthh";
    private static final String RELEASE_DATE = "ReleaseDate";
    private static final String ACTORS = "Actors";
    private static final String GENRES = "Genres";
    private static final String REDATELJ = "Redatelj";

    private static final String CREATE_MOVIE = "{ CALL createMovie (?,?,?,?,?,?,?,?,?,?) }";
    private static final String UPDATE_MOVIE = "{ CALL updateMovie (?,?,?,?,?,?,?,?,?,?) }";
    private static final String DELETE_MOVIE = "{ CALL deleteMovie (?) }";
    private static final String DELETE_MOVIES = "{ CALL deleteMovies }";
    private static final String SELECT_MOVIE = "{ CALL selectMovie (?) }";
    private static final String SELECT_MOVIES = "{ CALL selectMovies }";

    //MovieActor table
    private static final String CREATE_MOVIE_ACTOR = "{ CALL createMovieActor (?,?,?) }";
    private static final String DELETE_MOVIE_ACTORS = "{ CALL deleteMovieActors (?) }";

    //MovieGenre table 
    private static final String CREATE_MOVIE_GENRE = "{ CALL createMovieGenre (?,?,?) }";
    private static final String DELETE_MOVIE_GENRES = "{ CALL deleteMovieGenres (?) }";

    @Override
    public int createEntity(Movie movie) throws Exception {
        //Movie
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_MOVIE)) {
            stmt.setString(1, movie.getTitle());
            stmt.setString(2, movie.getOriginalName());
            stmt.setString(3, movie.getPublishedDate().format(Movie.PUB_DATE_FORMAT));
            stmt.setString(4, movie.getDescription());
            stmt.setInt(5, movie.getDirector().getId());
            stmt.setString(6, movie.getImagePath());
            stmt.setString(7, movie.getLink());
            stmt.setString(8, movie.getReleaseDate().format(Movie.RELEASE_DATE_FORMAT));
            stmt.setInt(9, movie.getLength());

            stmt.registerOutParameter(10, Types.INTEGER);

            stmt.executeUpdate();

            movie.setId(stmt.getInt(10)); //needed for creating movieGenres and movieActors
        }
        //MovieGenre MovieActors tables
        createMovieGenres(movie.getId(), new ArrayList<>(movie.getGenres()));
        createMovieActors(movie.getId(), new ArrayList<>(movie.getActors()));

        return movie.getId();
    }

    @Override
    public void createEntities(List<Movie> movies) throws Exception {

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_MOVIE)) {
            for (Movie movie : movies) {
                if (movie.getDirector() == null) { //some movies from blitz-cinestar do not have directors. since we need an existing person as director (person which has an id), we handle this by not adding those movies to database
                    Files.deleteIfExists(Paths.get(movie.getImagePath()));//we must check if an movie has an stored image in our file system. if so, we need to remove it.
                } else {
                    stmt.setString(1, movie.getTitle());
                    stmt.setString(2, movie.getOriginalName());
                    stmt.setString(3, movie.getPublishedDate().format(Movie.PUB_DATE_FORMAT));
                    stmt.setString(4, movie.getDescription());
                    stmt.setInt(5, movie.getDirector().getId());
                    stmt.setString(6, movie.getImagePath());
                    stmt.setString(7, movie.getLink());
                    stmt.setString(8, movie.getReleaseDate().format(Movie.RELEASE_DATE_FORMAT));
                    stmt.setInt(9, movie.getLength());

                    stmt.registerOutParameter(10, Types.INTEGER);

                    stmt.executeUpdate();

                    movie.setId(stmt.getInt(10));
                }

            }

            for (Movie movie : movies.stream().filter(m -> m.getId() != 0).collect(Collectors.toList())) { //for those movies who are succesfuly stored in database (we do this by checking movie's ID) create movie Genres and actors.
                createMovieGenres(movie.getId(), new ArrayList<>(movie.getGenres()));
                createMovieActors(movie.getId(), new ArrayList<>(movie.getActors()));
            }
        }
    }

    @Override
    public void updateEntity(int id, Movie data) throws Exception {

        //For this id(movie) update Actors/Genres...
        updateMovieGenres(id, new ArrayList<>(data.getGenres()));
        updateMovieActors(id, new ArrayList<>(data.getActors()));

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(UPDATE_MOVIE)) {
            stmt.setString(1, data.getTitle());
            stmt.setString(2, data.getOriginalName());
            stmt.setString(3, data.getPublishedDate().format(Movie.PUB_DATE_FORMAT));
            stmt.setString(4, data.getDescription());
            stmt.setInt(5, data.getDirector().getId());
            stmt.setString(6, data.getImagePath());
            stmt.setString(7, data.getLink());
            stmt.setString(8, data.getReleaseDate().format(Movie.RELEASE_DATE_FORMAT));
            stmt.setInt(9, data.getLength());

            stmt.setInt(10, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteEntity(int id) throws Exception {
        deleteMovieActors(id);
        deleteMovieGenres(id);

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIE)) {
            stmt.setInt(1, id);

            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteEntities() throws Exception {

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIES)) {

            stmt.executeUpdate();
        }
    }

    @Override
    public Optional<Movie> selectEntity(int id) throws Exception {

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_MOVIE)) {
            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Movie(
                            rs.getInt(ID_MOVIE),
                            rs.getString(TITLE),
                            rs.getString(ORIGINAL_NAME),
                            LocalDateTime.parse(rs.getString(PUBLISHED_DATE), Movie.PUB_DATE_FORMAT),
                            rs.getInt(LENGTH),
                            rs.getString(DESCRIPTION),
                            getGenres(rs.getString(GENRES)),
                            Person.parseFromString(rs.getString(REDATELJ)),
                            getPersons(rs.getString(ACTORS)),
                            rs.getString(IMAGE_PATH),
                            rs.getString(LINK),
                            LocalDate.parse(rs.getString(RELEASE_DATE), Movie.RELEASE_DATE_FORMAT)));
                }
            }
            return Optional.empty();
        }
    }

    @Override
    public List<Movie> selectEntities() throws Exception {
        List<Movie> movies = new ArrayList<>();

        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(SELECT_MOVIES)) {
            try (ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt(ID_MOVIE),
                            rs.getString(TITLE),
                            rs.getString(ORIGINAL_NAME),
                            LocalDateTime.parse(rs.getString(PUBLISHED_DATE), Movie.PUB_DATE_FORMAT),
                            rs.getInt(LENGTH),
                            rs.getString(DESCRIPTION),
                            getGenres(rs.getString(GENRES)),
                            Person.parseFromString(rs.getString(REDATELJ)),
                            getPersons(rs.getString(ACTORS)),
                            rs.getString(IMAGE_PATH),
                            rs.getString(LINK),
                            LocalDate.parse(rs.getString(RELEASE_DATE), Movie.RELEASE_DATE_FORMAT)));
                }

                return movies;
            }
        }
    }
    //For this movieId create actors

    private void createMovieActors(int movieId, List<Person> actors) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_MOVIE_ACTOR)) {
            for (Person actor : actors) {

                stmt.setInt(1, movieId);
                stmt.setInt(2, actor.getId());

                //we dont need this, but we must be consistant -> Sql procedure -> Ako nesto kreiras vrati novo kreiran ID! 
                stmt.registerOutParameter(3, Types.INTEGER);

                stmt.executeUpdate();
            }

        }
    }

    private void updateMovieActors(int movieId, List<Person> actors) throws Exception {
        deleteMovieActors(movieId);
        createMovieActors(movieId, actors);
    }

    private void deleteMovieActors(int movieId) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIE_ACTORS)) {
            stmt.setInt(1, movieId);

            stmt.executeUpdate();
        }
    }

    private void createMovieGenres(int movieId, List<Genre> genres) throws Exception {
        if (genres.isEmpty()) {
            return;
        }
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(CREATE_MOVIE_GENRE)) {
            for (Genre genre : genres) {
                stmt.setInt(1, movieId);
                stmt.setInt(2, genre.getId());

                stmt.registerOutParameter(3, Types.INTEGER);

                stmt.executeUpdate();
            }

        }
    }

    //For this id of movie update genres
    private void updateMovieGenres(int movieId, List<Genre> genres) throws Exception {
        deleteMovieGenres(movieId);
        createMovieGenres(movieId, genres);
    }

    private void deleteMovieGenres(int movieId) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_MOVIE_GENRES)) {
            stmt.setInt(1, movieId);

            stmt.executeUpdate();
        }
    }

    //1 akcija,2 horror
    private Set getGenres(String string) {
        Set<Genre> genres = new TreeSet<>();
        if (string != null && !string.isEmpty()) {
            //1 akcija
            String[] data = string.split(",");

            for (String genre : data) {
                String[] individualProp = genre.split(" ");
                genres.add(new Genre(Integer.parseInt(individualProp[0].trim()), individualProp[1].trim()));
            }
        }
        return genres;
    }

    private Set getPersons(String string) {
        Set<Person> persons = new TreeSet<>();

        if (string != null && !string.isEmpty()) {

            //1 Bradd pitt
            String[] data = string.split(",");

            for (String person : data) {
                String[] individualProp = person.split(" ");

                String id = individualProp[0].trim();
                String firstName = individualProp[1].trim();
                String lastName = person.substring(id.length() + firstName.length() + 1).trim(); //evrything else except id and firstName we put in lastname (in case if user has middlename..)

                persons.add(new Person(Integer.parseInt(id), firstName, lastName));
            }
        }
        return persons;
    }

}
