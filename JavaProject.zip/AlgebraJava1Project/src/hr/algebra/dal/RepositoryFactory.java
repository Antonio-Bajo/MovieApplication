/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.dal;

import hr.algebra.dal.sql.GenreRepository;
import hr.algebra.dal.sql.MovieRepository;
import hr.algebra.dal.sql.PersonRepository;
import hr.algebra.model.Genre;
import hr.algebra.model.Movie;
import hr.algebra.model.Person;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 *
 * @author Antonio
 */
public class RepositoryFactory {

    //wildcard type instead of raw types(raw types should be avoided).
    private static final Map<Class<?>, Supplier<Repository<?>>> MAP = new HashMap<>();

    static {
        MAP.put(Movie.class, MovieRepository::new);
        MAP.put(Person.class, PersonRepository::new);
        MAP.put(Genre.class, GenreRepository::new);
    }

    private RepositoryFactory() {
    }

    /**
     * Returns new instance of parameterized repository where type parameter is
     * defined by passed Class
     *
     * @param <T>
     * @param clazz defines which type parameter of Repository will be returned.
     * @return new instance of implementator of repository<>.
     */
    public static <T> Repository<T> getRepository(Class<T> clazz) {
        if (MAP.containsKey(clazz)) {
            return (Repository<T>) MAP.get(clazz).get(); //typesafe if MAP is filled correctly (which is).
        }
        throw new IllegalArgumentException("No such repository");

    }
}
