/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.parsers.rss;

import hr.algebra.dal.RepositoryFactory;
import hr.algebra.factory.ParserFactory;
import hr.algebra.factory.UrlConnectionFactory;
import hr.algebra.model.Genre;
import hr.algebra.model.Person;
import hr.algebra.utils.FileUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import hr.algebra.dal.Repository;
import hr.algebra.model.Movie;

/**
 *
 * @author Antonio
 */
public class MovieParser {

    private static final String RSS_URL = "https://www.blitz-cinestar.hr/rss.aspx?najava=1";
    private static final String EXT = ".jpg";
    private static final String DIR = "assets";

    private static Repository<Person> personRepository;
    private static Repository<Genre> genreRepository;

    private static void handlePicture(Movie movie, String url) {
        try {//ako to pukne moramo nastavit dalje, nema slike za taj article

            //we ensure extension
            String ext = url.substring(url.lastIndexOf("."));
            if (ext.length() > 4) {
                ext = EXT;
            }

            //2. we create file path of picture
            String pictureName = UUID.randomUUID() + ext;  //333232323.jpg
            String path = DIR + File.separator + pictureName; // assets/333232323.jpg;

            //3. copy from url to our path
            FileUtils.copyFromUrl(url, path);

            movie.setImagePath(path);
        } catch (IOException ex) {
            Logger.getLogger(MovieParser.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private MovieParser() {
    }

    public static List<Movie> parse() throws Exception {
        List<Movie> movies = new ArrayList<>();

        personRepository = RepositoryFactory.getRepository(Person.class);
        genreRepository = RepositoryFactory.getRepository(Genre.class);

        //1. otvoriti konekciju za RSS_URL
        HttpURLConnection con = UrlConnectionFactory.getHttpUrlsConnection(RSS_URL);

        //2. otvoriti stream nad konekcijom
        try (InputStream is = con.getInputStream()) {
            XMLEventReader reader = ParserFactory.CreateStaxParser(is); //pull parser

            StartElement startElement = null;
            Movie movie = null;
            Optional<TagType> tagType = Optional.empty();

            while (reader.hasNext()) {
                XMLEvent event = reader.nextEvent(); //tagovi i textovi

                switch (event.getEventType()) {  //EventType moze biti start_element ili characters

                    case XMLStreamConstants.START_ELEMENT: //title, kad dodjemo do start_element , hvatamo taj tag (TagType)
                        startElement = event.asStartElement();
                        String qName = startElement.getName().getLocalPart(); //qName = "item","title"....
                        tagType = TagType.from(qName); // ili ce nastati onaj koji nam treba, ili ce biti empty
                        break;

                    case XMLStreamConstants.CHARACTERS:
                        Characters characters = event.asCharacters();
                        String data = characters.getData().trim();
                        if (tagType.isPresent()) {

                            switch (tagType.get()) {
                                case ITEM:
                                    movie = new Movie();
                                    movies.add(movie);
                                    break;
                                case TITLE:
                                    if (movie != null && !data.isEmpty()) {
                                        movie.setTitle(data);
                                    }
                                    break;
                                case PUBDATE:
                                    if (movie != null && !data.isEmpty()) {
                                        LocalDateTime pubDate = LocalDateTime.parse(data, DateTimeFormatter.RFC_1123_DATE_TIME); //Sun, 19 Dec 2021 16:12:39 GMT
                                        movie.setPublishedDate(pubDate);
                                    }
                                    break;
                                case DESCRIPTION:
                                    if (movie != null && !data.isEmpty()) {
                                        movie.setDescription(data);
                                    }
                                    break;
                                case ORIGNAZIV:
                                    if (movie != null && !data.isEmpty()) {
                                        movie.setOriginalName(data);
                                    }
                                    break;
                                case REDATELJ:
                                    if (movie != null && !data.isEmpty()) {
                                        if (data.contains(",")) { 
                                            data = data.substring(0,data.indexOf(",")).trim();
                                        }
                                        String[] info =data.split(" ");
                                        if (info.length > 2) {//if it has length bigger then 2, npr Yahya Abdul-Mateen II
                                            Arrays.stream(info).skip(2).forEach(p -> info[1] += (" " + p)); // put all surnames/middlenames.. in lastName (info[1])
                                        }

                                        //for some reason redatelj can have only FirstName...
                                        Person redatelj = info.length < 2
                                                ? personRepository.createOrGetEntity(new Person(info[0], ""))
                                                : personRepository.createOrGetEntity(new Person(info[0], info[1]));

                                        movie.setDirector(redatelj);
                                    }
                                    break;
                                case GLUMCI:
                                    if (movie != null && !data.isEmpty()) {
                                        String[] line = data.split(",");

                                        for (String stringPerson : line) { //Yahya Abdul-Mateen II
                                            String[] info = stringPerson.trim().split(" "); //Yahya, Abdul-Mateen, II 
                                            if (info.length > 2) {//if it has length bigger then 2, npr Yahya Abdul-Mateen II
                                                Arrays.stream(info).skip(2).forEach(p -> info[1] += (" " + p)); // put all surnames/middlenames.. in lastName (info[1])
                                            }

                                            //for some reason actors can have only FirstName...
                                            Person actor = info.length < 2
                                                    ? personRepository.createOrGetEntity(new Person(info[0], ""))
                                                    : personRepository.createOrGetEntity(new Person(info[0], info[1]));
                                            
                                            movie.addActor(actor);
                                        }
                                    }
                                    break;
                                case TRAJANJE:
                                    if (movie != null && !data.isEmpty()) {
                                        movie.setLength(Integer.parseInt(data));
                                    }
                                    break;
                                case ZANR:
                                    if (movie != null && !data.isEmpty()) {
                                        String[] line = data.split(",");

                                        for (String info : line) {
                                            Genre genre = genreRepository.createOrGetEntity(new Genre(info.trim()));
                                            movie.addGenre(genre);
                                        }
                                    }
                                    break;
                                case PLAKAT:
                                    if (movie != null && !data.isEmpty()) {
                                        handlePicture(movie, data);
                                    }
                                    break;
                                case LINK:
                                    if (movie != null && !data.isEmpty()) {
                                        movie.setLink(data);
                                    }
                                    break;
                                case POCETAK:
                                    if (movie != null && !data.isEmpty()) {
                                        LocalDate pocetak = LocalDate.parse(data, DateTimeFormatter.ofPattern("d[d].M[M].yyyy")); //1.6.2020
                                        movie.setReleaseDate(pocetak);

                                    }
                                    break;
                                default:
                                    throw new AssertionError(tagType.get().name());

                            }
                        }
                        break;
                }
            }

        }
        return movies;
    }

    //static! Possible memory loss if not. (we dont need tight reletionship)
    private static enum TagType {

        ITEM("item"),
        TITLE("title"),
        PUBDATE("pubDate"),
        DESCRIPTION("description"),
        ORIGNAZIV("orignaziv"),
        REDATELJ("redatelj"),
        GLUMCI("glumci"),
        TRAJANJE("trajanje"),
        ZANR("zanr"),
        PLAKAT("plakat"),
        LINK("link"),
        POCETAK("pocetak");

        private final String name;

        private TagType(String name) {
            this.name = name;
        }

        public static Optional<TagType> from(String name) {

            for (TagType value : TagType.values()) {
                if (value.name.equals(name)) {
                    return Optional.of(value);
                }
            }
            return Optional.empty();

        }
    }
}
