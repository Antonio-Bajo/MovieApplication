/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.utils;

import javax.swing.JOptionPane;

/**
 *
 * @author Antonio
 */
public class MessegeUtils {

    private MessegeUtils() {
    }

    public static void showErrorMessege(String title, String messege) {
        JOptionPane.showMessageDialog(null, messege, title, JOptionPane.ERROR_MESSAGE);
    }

    public static void showInfoMessege(String title, String messege) {
        JOptionPane.showMessageDialog(null, messege, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static int showConfirmDialog(String title, String messege) {
        return JOptionPane.showConfirmDialog(null, messege, title, JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
    }

}
