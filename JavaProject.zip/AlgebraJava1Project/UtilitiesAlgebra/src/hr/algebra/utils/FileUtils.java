/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.utils;

import hr.algebra.factory.UrlConnectionFactory;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.IntStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Antonio
 */
public class FileUtils {

    private static final String SAVE = "Save";
    private static final String TEXT_DOCUMENTS = "Text documents (*.txt)";
    private static final String TXT = "txt";

   
    public static boolean filenameHasExtension(String filename, int... length) {
        return filename.contains(".") && IntStream.of(length).anyMatch(l -> filename.substring(filename.lastIndexOf(".") + 1).length() == l);

    }

    private FileUtils() {
    }

    private static final String UPLOAD = "Upload";

    public static Optional<File> uploadFile(String description, String... extensions) {
        JFileChooser chooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        chooser.setFileFilter(new FileNameExtensionFilter(description, extensions));
        chooser.setDialogTitle(UPLOAD);
        chooser.setApproveButtonText(UPLOAD);
        chooser.setApproveButtonToolTipText(UPLOAD);
        chooser.setAcceptAllFileFilterUsed(false);
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            //izvuci selectedFile
            File selectedFile = chooser.getSelectedFile();
            //izvuci extension od selectedFile
            String extension = selectedFile.getName().substring(selectedFile.getName().lastIndexOf(".") + 1);
            //I returnaj file ako containa taj extension, ako ne onda returnaj OptionalEmpty!
            return Arrays.asList(extensions).contains(extension.toLowerCase()) ? Optional.of(selectedFile) : Optional.empty();
        }
        return Optional.empty();
    }

    //(Vjezbe0910 zad2)  0:55:00 video
    //1. save -> prima optFile koji ce biti present
    //2. save as -> prima optFile koji ce biti empty!
    public static Optional<File> saveTextInFile(String text, Optional<File> optFile) throws IOException {
        //saveAs 
        if (!optFile.isPresent()) {
            JFileChooser chooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            chooser.setFileFilter(new FileNameExtensionFilter(TEXT_DOCUMENTS, TXT));
            chooser.setDialogTitle(SAVE);
            chooser.setApproveButtonText(SAVE);
            chooser.setApproveButtonToolTipText(SAVE);
            chooser.setAcceptAllFileFilterUsed(false);
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                File selectedFile = chooser.getSelectedFile();
                //imam li ext?
                if (!selectedFile.toString().endsWith(TXT)) {
                    selectedFile = new File(selectedFile.toString().concat(".").concat(TXT));
                }
                Files.write(selectedFile.toPath(), text.getBytes());
                optFile = Optional.of(selectedFile);
            }
        } else {
            //save
            //file vec postoji
            Files.write(optFile.get().toPath(), text.getBytes());
        }

        return optFile;
    }

    public static Optional<String> loadTextFromFile() throws IOException {
        JFileChooser chooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        chooser.setFileFilter(new FileFilter() {
            @Override
            public boolean accept(File file) {
                //dopustam samo direktorije i txt filove
                return file.isDirectory() || file.toString().endsWith(TXT);
            }

            @Override
            public String getDescription() {
                return TEXT_DOCUMENTS;
            }
        });
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            return Optional.of(new String(Files.readAllBytes(chooser.getSelectedFile().toPath())));
        }

        return Optional.empty();
    }

    //Source:   //https://static.slobodnadalmacija.hr/images/slike/2021/12/08/20264024.jpg
    //Destination:  assets/files/upload/12312451.jpg ili assets/333232323.jpg;, ovisi sta stavimpo
    public static void copyFromUrl(String source, String destination) throws IOException {
        createDirHierarchy(destination); //potrebno jer moguce da nemamo taj direktoriiji
        HttpURLConnection con = UrlConnectionFactory.getHttpUrlsConnection(source); //zakvacili smo se na sliku

        try (InputStream is = con.getInputStream()) {
            Files.copy(is, Paths.get(destination));
        }

    }

    //lokalno, npr iz c://...  u d://...
    public static void copy(String source, String destination) throws IOException {
        createDirHierarchy(destination); //potrebno jer moguce da nemamo taj direktoriiji
        Files.copy(Paths.get(source), Paths.get(destination));

    }

    //assets/files/upload/12312451.jpg
    private static void createDirHierarchy(String destination) throws IOException {
        String dir = destination.substring(0, destination.lastIndexOf(File.separator));//assets/files/upload
        if (!Files.exists(Paths.get(dir))) { //ako ne postoji ovo
            Files.createDirectories(Paths.get(dir));  //onda ga moras kreirat
        }
    }

}
